Data packaged around 2021-02-28 by OpenAddresses (http://openaddresses.io).

Website: http://www.censo2010.ibge.gov.br/cnefe/
License: Unknown
